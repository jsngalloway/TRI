package elfoe.trulyrandomimgur;

import android.util.Log;

import java.util.Arrays;

public class ImageData {
    String url;
    String fileType;
//    String title;
//    String desc;
//    String date;
//    int views;
    private String[] acceptable_fileTypes = {"JPG", "PNG", "GIF", "MP4"};

    ImageData(String url, String fileType){
        this.url = url;
        fileType = fileType.toUpperCase();

        if (!Arrays.asList(acceptable_fileTypes).contains(fileType)){
            Log.e("DEBUG: ","Unacceptable filetype: " + fileType);
        } else {
            this.fileType = fileType;
        }
    }
}
