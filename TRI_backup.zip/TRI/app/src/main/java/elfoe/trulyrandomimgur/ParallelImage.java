package elfoe.trulyrandomimgur;

import android.util.Log;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Random;

public class ParallelImage extends Thread {
    String url;
    RandomImage ri;

    public ParallelImage(String url, UrlList urlList) {
        this.url = url;
        this.ri = new RandomImage(urlList);
    }

    public void run() {
        if (ri.validateURL(url)) {
            String fileType  = ri.getImageType(url);
            //Log.e("DEBUG: ","FILE TYPE IS: " + fileType);
            RandomImage.success++;
            Log.e("DEBUG: ",(float) RandomImage.count / (System.currentTimeMillis() / 1000 - RandomImage.startTime / 1000) + " URL/sec " + (int) (RandomImage.count / RandomImage.success) + " fail/win. \t" + url + " ." + fileType);
            //ri.getImageType(url);
            ri.addToList(url, fileType);
        }
    }
}

