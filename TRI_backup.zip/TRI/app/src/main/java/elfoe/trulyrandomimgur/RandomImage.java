package elfoe.trulyrandomimgur;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class RandomImage {
    String upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    String lower = upper.toLowerCase();
    String numbers = "0123456789";
    String all = upper + lower + numbers;
    static long count = 0;

    public static final long IMAGE_THRESHOLD = 300*300;
    public static long success = 0;
    public static long startTime;
    static final int MAX_THREADS = 16;
    UrlList urlList;

    public RandomImage(UrlList urlList){
        this.urlList = urlList;
    }

    String randomString(int length){
        String ret = "";
        int Alllength = all.length();
        for(int i = 0; i < length; i++) {
            int randInt = (int) (Math.random() * Alllength);
            ret = ret + all.charAt(randInt);
        }
        return ret;
    }
    String getTitle(String url) {
        HttpURLConnection.setFollowRedirects(false);
        InputStream response = null;
        String title = null;
        try {
            response = new URL(url).openStream();
            Scanner scanner = new Scanner(response);
            String responseBody = scanner.useDelimiter("\\A").next();
            try {
                title = responseBody.substring(responseBody.indexOf("<title>") + 7, responseBody.indexOf("</title>"));
            } catch (Exception e) {
                Log.e("DEBUG: ","Error with URL: " + url);
                if (responseBody.substring(0, 20).contains("PNG")) {
                    //it's a PNG
                    scanner.close();
                    return "PNG";
                }
                e.printStackTrace();
            }
            scanner.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            try {
                response.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        return title;
    }
    boolean getResponseCode(String url) throws IOException {
        HttpURLConnection.setFollowRedirects(false);
        URL u = new URL (url);
        HttpURLConnection huc =  (HttpURLConnection) u.openConnection();
        huc.setRequestMethod ("GET");//TODO
        huc.connect();
        int code = huc.getResponseCode();
        //if (code == 200)Log.e("DEBUG: ","SizeHead: " + huc.getContentLengthLong());
        huc.disconnect();
        return (code == 200);
    }
    long getPictureSize(String url_str) {
        HttpURLConnection.setFollowRedirects(false);
        try {
            URL url = new URL(url_str);
            Bitmap bmp = BitmapFactory.decodeStream(url.openConnection().getInputStream());
            return bmp.getWidth() * bmp.getHeight();
        } catch (MalformedURLException e1) {
            Log.e("DEBUG: ","Failed to parse URL");
            e1.printStackTrace();
        } catch (IOException e) {
            Log.e("DEBUG: ","Failed to load image");
            e.printStackTrace();
        }
        Log.e("DEBUG: ","Failed to load image size. Terminating");
        System.exit(2);
        return -1;
    }
    public boolean validateURL(String url){
        HttpURLConnection.setFollowRedirects(false);
        RandomImage ri = new RandomImage(urlList);
        //TODO I'm pretty sure we can move a bunch of this out of random Image.
        try {
            if (ri.getResponseCode(url + ".jpg")) {
                //we have have response code 200
                long imgSize = ri.getPictureSize(url + ".jpg");
                if(imgSize >= IMAGE_THRESHOLD) {
                    //the image is large enough or it's a GIF or mp4
                    return true;
                } else if (gifOrPng(url + ".jpg") == "GIF"  || ri.getResponseCode(url + ".mp4")) {
                    Log.e("DEBUG: ","Small but special excepiton made for animated image: " + url);
                    return true;
                } else {

                    if (imgSize < IMAGE_THRESHOLD) {
                        Log.e("DEBUG: ","Valid image but failed due to [size] (" + (IMAGE_THRESHOLD-imgSize) + " pixles too small) GIF: " + (gifOrPng(url + ".jpg") == "GIF") + " MP4: " + (ri.getResponseCode(url + ".mp4")) + " " + url);
                        //Log.e("DEBUG: ",imgSize);
                    } else {
                        Log.e("DEBUG: ","Unknown failure occured");
                        System.exit(2);
                    }
                    return false;
                }
            }
        } catch (IOException e) {
            Log.e("DEBUG: ","Unable to get valid response from: " + url);
            e.printStackTrace();
        }
        return false;
    }
    public void addToList(String url, String fileType){
        urlList.addUrl(new ImageData(url, fileType));
    }
    public String gifOrPng(String url_str) {
        HttpURLConnection.setFollowRedirects(false);
        try
        {
            URL url = new URL(url_str);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            //HttpURLConnection.setFollowRedirects(true);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));

            String firstLine = bufferedReader.readLine();
            bufferedReader.close();
            urlConnection.disconnect();
            if (firstLine.contains("GIF")){
                Log.e("DEBUG: ","Special exception since it's a gif.");
                return "GIF";
            } else if (firstLine.contains("ftyp")) {
                //Log.e("DEBUG: ","It's a png.");
                return "MP4";
            } else if (firstLine.contains("PNG")) {
                return "PNG";
            } else {
                return null;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }
    public String getImageType(String url_str){
        //Log.e("DEBUG: ","Testing image type for: " + url_str);
        HttpURLConnection.setFollowRedirects(false);
//        try {
//            if (this.getResponseCode(url_str + ".mp4")) {
//                return "MP4";
//            }
//        } catch (IOException e) {
//            Log.e("DEBUG: ","Unable to verify the URL: " + url_str + ".mp4 Unknown error.");
//            e.printStackTrace();
//        }

        try
        {
            URL url = new URL(url_str + ".jpg");
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));

            String firstLine = bufferedReader.readLine();
            bufferedReader.close();
            urlConnection.disconnect();
            //Log.e("DEBUG: ",firstLine);
            if (firstLine.contains("GIF")){
                return "GIF";
            } else if (firstLine.contains("ftyp")) {
                return "MP4";
            } else if (firstLine.contains("PNG")) {
                return "PNG";
            } else if (firstLine.contains("JFIF") || (firstLine.contains("ICC_PROFILE"))){
                return "JPG";
            } else{
                Log.e("DEBUG:", "JPG by default.");
                return "JPG";
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }

}
