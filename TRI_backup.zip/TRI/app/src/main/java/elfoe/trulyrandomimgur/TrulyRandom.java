package elfoe.trulyrandomimgur;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import static java.lang.Math.round;

public class TrulyRandom extends AppCompatActivity {

    private TextView mTextMessage;
    public static TextView urlsMessage;
    private FloatingActionButton nextBtn;
    private ImageView imageView;
    private TextView urlDisplay;
    private static TextView urlsPerSec;
    public static Context context;
    private Switch generatorSwitch;
    private UrlGenerator mainGenerator;

    public static UrlList urlList;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    mTextMessage.setText(R.string.title_home);
                    return true;
                case R.id.navigation_dashboard:
                    mTextMessage.setText(R.string.title_dashboard);
                    return true;
                case R.id.navigation_notifications:
                    mTextMessage.setText(R.string.title_notifications);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        context = getApplicationContext();
        setContentView(R.layout.activity_truly_random);

        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        urlDisplay = (TextView) findViewById(R.id.textViewUrl);
        urlsPerSec = (TextView) findViewById(R.id.urlsPerSecView);
        urlsMessage = (TextView) findViewById(R.id.urlsBuffered);
        urlsMessage.setText("0");
        nextBtn = (FloatingActionButton) findViewById(R.id.btnNext);
        imageView = (ImageView) findViewById(R.id.imageDisplay);
        generatorSwitch = (Switch) findViewById(R.id.UrlGeneratorSwitch);

        Picasso.get().load("http://i.imgur.com/DvpvklR.png").into(imageView);

        //ImageData a = UrlGenerator.getNextUrl();
        //Picasso.get().load(a.url + "." + a.fileType.toLowerCase()).into(imageView);

        nextBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.e("TrulyRandom.java: ","Button clicked, displaying next url");
                if(urlList != null && urlList.getUrlListSize() > 0) {
                    ImageData i = urlList.getNextUrl();
                    Picasso.get().load(i.url + "." + i.fileType.toLowerCase()).into(imageView);
                    urlDisplay.setText(i.url);
                } else {
                    //no urls ready to go
                    Toast.makeText(context, "No URLS ready", Toast.LENGTH_SHORT).show();
                }
            }
        });

        generatorSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    Log.e("On switch flip","starting generator");
                    clearUrlsPerSecond();
                    mainGenerator = startGenerator();
                } else {
                    Log.e("On switch flip","stopping generator");
                    stopGenerator(mainGenerator);
                }
            }
        });


    }

    public static void setUrlsMessage(String newText){
                urlsMessage.setText("Urls ready: " + newText);
    }
    public static void setUrlsPerSecond(float urlsSec){
        String display = "%d03 URLs/sec";
        display = String.format(display, Math.round(urlsSec));
        urlsPerSec.setText(display);
    }
    private static void clearUrlsPerSecond(){
        urlsPerSec.setText("--- URLs/sec");
    }

    public UrlGenerator startGenerator(){
        urlList = new UrlList(context);
        Log.e("TrulyRandom.java: ", "urlList Created");
        UrlGenerator urlGen = new UrlGenerator(urlList);
        Log.e("TrulyRandom.java: ", "urlGen Created");
        urlGen.start();
        return urlGen;
    }

    public void stopGenerator(UrlGenerator generatorToStop){
        generatorToStop.turnOff();
        clearUrlsPerSecond();
    }

}
