package elfoe.trulyrandomimgur;

import android.content.Context;

import java.net.HttpURLConnection;
import java.util.LinkedList;
import android.os.Handler;
import android.util.Log;

public class UrlGenerator extends Thread {
    UrlList urlList;
    boolean running;
    long count = 0;

    public UrlGenerator(UrlList urlList){
        this.urlList = urlList;
    }

    public void run(){
        running = true;
        generator();
    }

    public void turnOff(){
        running = false;
    }

    private void generator(){
        HttpURLConnection.setFollowRedirects(false);
        RandomImage ri = new RandomImage(urlList);
        RandomImage.startTime = System.currentTimeMillis();
        String url = null;

        while ((UrlList.getUrlListSize() < UrlList.getList_cap()) && running ) {
            url = ("https://i.imgur.com/" + ri.randomString(7));
            RandomImage.count++;
            ParallelImage pit = new ParallelImage(url, urlList);
            pit.start();
            while ((Thread.activeCount() > RandomImage.MAX_THREADS) && (UrlList.getUrlListSize() < UrlList.getList_cap())) {
                try {
                    urlList.updateUrlsPerSecond();
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    Log.e("DEBUG: ","Handler thread interrupted");
                    e.printStackTrace();
                }
            }
        }
    }
}
