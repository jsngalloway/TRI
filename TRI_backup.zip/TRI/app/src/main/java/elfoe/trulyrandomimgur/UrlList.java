package elfoe.trulyrandomimgur;

import android.content.Context;
import android.os.Handler;

import java.util.LinkedList;

public class UrlList {
    private static int list_cap = 10;
    private static LinkedList<ImageData> url_list = new LinkedList<ImageData>();
    public long count = 0;
//
//    public UrlList(){
//        //empty constructor
//    }

    private final Handler handler;

    public UrlList(Context context){
        handler = new Handler(context.getMainLooper());
    }
    private void runOnUiThread(Runnable r) {
        handler.post(r);
    }

    public static int getUrlListSize(){
        return url_list.size();
    }
    public static int getList_cap(){
        return list_cap;
    }
    public static String getUrlListSizeStr(){
        return getUrlListSize() + "";
    }
    public ImageData getNextUrl(){
        ImageData ret = url_list.getFirst();
        url_list.removeFirst();
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
//                 Stuff that updates the UI
                TrulyRandom.setUrlsMessage(getUrlListSizeStr());
            }
        });

        return ret;
    }
    public String getNextDirectUrl(){
        ImageData ret = url_list.getFirst();
        url_list.removeFirst();
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
//                 Stuff that updates the UI
                TrulyRandom.setUrlsMessage(getUrlListSizeStr());
            }
        });

        return ret.url + "." + ret.fileType.toLowerCase();
    }
    public void addUrl(ImageData toAdd){
        url_list.add(toAdd);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                 //Code to run on UI thread
                TrulyRandom.setUrlsMessage(getUrlListSizeStr());
            }
        });
        return;
    }

    public void updateUrlsPerSecond(){
        final float perSec = count / ((System.currentTimeMillis() / 1000)+1 - (RandomImage.startTime / 1000));
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                TrulyRandom.setUrlsPerSecond(perSec);
            }
        });
    }
}
